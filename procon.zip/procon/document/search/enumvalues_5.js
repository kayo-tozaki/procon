var searchData=
[
  ['string_5ftype',['string_type',['../namespacepicojson.html#acbcfb4072b62a8a097a2aaf7a8f8cc02a3cb2900f95eb6459ee2fe4e9a111bef8',1,'picojson']]]
];
