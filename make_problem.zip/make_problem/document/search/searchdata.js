var indexSectionsWithContent =
{
  0: "_abcdefghijlmnoprstuvw~",
  1: "_dhijlnpsv",
  2: "ps",
  3: "hijlps",
  4: "_acdefghijlmnoprstuvw~",
  5: "abcelnostu",
  6: "ao",
  7: "abinos",
  8: "dgimps"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "全て",
  1: "クラス",
  2: "名前空間",
  3: "ファイル",
  4: "関数",
  5: "変数",
  6: "型定義",
  7: "列挙値",
  8: "マクロ定義"
};

