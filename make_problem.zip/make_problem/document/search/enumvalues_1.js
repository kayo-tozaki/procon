var searchData=
[
  ['boolean_5ftype',['boolean_type',['../namespacepicojson.html#acbcfb4072b62a8a097a2aaf7a8f8cc02ae04a93ebe65786d1f8687430242df802',1,'picojson']]]
];
